# needed for finding out where module is installed
