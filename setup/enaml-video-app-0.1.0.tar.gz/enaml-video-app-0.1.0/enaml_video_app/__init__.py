# The following code gets path to __init__.py file of the package:

# import thepackage
# import inspect
# inspect.getfile(thepackage)
