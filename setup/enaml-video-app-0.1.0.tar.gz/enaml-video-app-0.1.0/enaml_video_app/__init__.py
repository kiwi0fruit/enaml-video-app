# The following code gets path to __init__.py file of the_package:
# import the_package
# import inspect
# inspect.getfile(the_package)
