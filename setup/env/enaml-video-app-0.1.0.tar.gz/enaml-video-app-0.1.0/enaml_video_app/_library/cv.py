"""
PyCharm inspection bug fix
"""
import cv2
# noinspection PyUnresolvedReferences
VideoCapture = cv2.VideoCapture
# noinspection PyUnresolvedReferences
cvtColor = cv2.cvtColor
# noinspection PyUnresolvedReferences
COLOR_BGR2GRAY = cv2.COLOR_BGR2GRAY
# noinspection PyUnresolvedReferences
COLOR_BGR2RGB = cv2.COLOR_BGR2RGB
